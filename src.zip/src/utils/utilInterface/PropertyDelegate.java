package utils.utilInterface;

/**
 * helper class that manager properties file
 * 
 * @author Danping Zhou (Modified Version)
 * @version 6.1.0, 22 Nov 2016
 *
 */
public abstract interface PropertyDelegate {
	public abstract String getStringProperty(String paramString);

	public abstract Object getObjectOfClass(String paramString);
}
