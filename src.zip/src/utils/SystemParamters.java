package utils;

/**
 * helper class that manager system paramters
 * 
 * @author Danping Zhou
 * @version 6.1.0, 22 Nov 2016
 */
public class SystemParamters {

	// operation_type 0-put items,1-drop items,2-turn around
	public static String OPERATION_TYPE_0 = "0";
	public static String OPERATION_TYPE_1 = "1";
	public static String OPERATION_TYPE_2 = "2";

	// xml file name
	public static String WORLD_VIEW_XML = "viewFile.xml";

	// world view path
	public static String WORLD_VIEW_PATH = "images/word/";

	// map view path
	public static String MAP_VIEW_PATH = "images/maps/";

	// items view path
	public static String ITEMS_VIEW_PATH = "images/portableItems/";

	// xml file name web url
	public static String WORLD_VIEW_XML_WEB = "http://www.yzufo.xyz/viewFile.xml";

	// world view web path
	public static String WORLD_VIEW_PATH_WEB = "http://www.yzufo.xyz/images/word/";

	// map view web path
	public static String MAP_VIEW_PATH_WEB = "http://www.yzufo.xyz/images/maps/";

	// items view web path
	public static String ITEMS_VIEW_PATH_WEB = "http://www.yzufo.xyz/images/portableItems/";

	// image suffix
	public static String IMAGE_SUFFIX = ".jpg";
	// maps suffix
	public static String MAP_SUFFIX = ".png";
	// items suffix
	public static String ITEMS_SUFFIX = ".png";

	// download xml file local path
	public static String DOWNLOAD_FILE_PATH = "temp";

	// download xml file local name
	public static String DOWNLOAD_FILE_NAME = "temp.xml";

}
