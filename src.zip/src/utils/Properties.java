package utils;

/**
 * A properties manager which can help search information from properties file
 * @author Danping Zhou(Modified Version)
 * @version 6.1.0, 22 Nov 2016 
 */
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;

import utils.utilInterface.PropertyDelegate;

public class Properties {
	private static Properties singleton;
	private static boolean debugging = false;
	private PropertyDelegate delegate = null;
	private java.util.Properties properties;

	private void load() {
		try {
			this.properties = new java.util.Properties();
			InputStream localInputStream = getClass().getClassLoader().getResourceAsStream("default.properties");
			this.properties.load(localInputStream);
		} catch (Exception localException1) {
			System.err.println("[error] Properties: failed to read default properties \"default.properties\"");
			System.exit(1);
		}
		if (debugging) {
			System.err.println("[debug] Properties: loaded default properties \"default.properties\"");
		}

		String str = (String) System.getenv().get("IJP1_PROPERTYPATH");
		if (str == null) {
			if (debugging) {
				System.err.println("[debug] Properties: no environment properties: $IJP1_PROPERTYPATH");
			}
		} else {
			if (debugging) {
				System.err.println("[debug] Properties: from $IJP1_PROPERTYPATH: \"" + str + "\"");
			}
			for (Object localObject2 : str.split(":")) {
				addProperties(Paths.get(((String) localObject2).trim(), new String[0]));
			}
		}
	}

	private static Properties theProperties() {
		if (singleton == null) {
			singleton = new Properties();
			singleton.load();
		}
		return singleton;
	}
	
	/**
	 * add properties to default.properties
	 * @param paramPath
	 */
	public static void addProperties(Path paramPath) {
		try {
			InputStream localInputStream = Files.newInputStream(paramPath, new OpenOption[0]);
			java.util.Properties localProperties = new java.util.Properties();
			localProperties.load(localInputStream);
			theProperties().properties.putAll(localProperties);
			if (debugging) {
				System.err.println("[debug] Properties: loaded user properties \"" + paramPath + "\"");
			}
		} catch (FileNotFoundException | NoSuchFileException localFileNotFoundException) {
			if (debugging) {
				System.err.println("[debug] Properties: no user properties \"" + paramPath + "\"");
			}
		} catch (Exception localException) {
			System.err.println("[error] Properties: failed to load properties \"" + paramPath + "\"\n"
					+ localException.toString());
			System.exit(1);
		}
	}

	/**
	 * get information from properties file by parameters 
	 * @param paramString
	 * @return
	 */
	public static String get(String paramString) {
		String str1 = getProperty(paramString);
		String str2 = str1 == null ? "<null>" : str1;
		if (debugging) {
			System.err.println("[debug] Properties: " + paramString + " = " + str2 + " (string)");
		}
		return str1;
	}
	/**
	 * get information from properties file by parameters 
	 * @param paramString
	 * @return
	 */
	private static String getProperty(String paramString) {
		if (delegate() != null) {
			String str = delegate().getStringProperty(paramString);
			if (str != null) {
				return str;
			}
		}
		return theProperties().properties.getProperty(paramString);
	}
	/**
	 * get object from properties file by parameters 
	 * @param paramString1
	 * @param paramString2
	 * @return
	 */
	public static Object getObject(String paramString1, String paramString2) {
		String str = getProperty(paramString1);
		return getObjectOfClass(str, paramString2);
	}

	/**
	 * get object class from properties file by parameters 
	 * @param paramString1
	 * @param paramString2
	 * @return
	 */
	public static Object getObjectOfClass(String paramString1, String paramString2) {
		String[] arrayOfString = paramString2.split(":");
		int i = arrayOfString.length;
		for (int j = 0; j < i;) {
			String str1 = arrayOfString[j];

			String str2 = (str1 + "." + paramString1).trim();
			Object localObject;
			if (delegate() != null) {
				localObject = delegate().getObjectOfClass(str2);
				if (localObject != null) {
					return localObject;
				}
			}
			try {
				localObject = Class.forName(str2);
				try {
					Method localMethod = ((Class) localObject).getMethod("factory", new Class[] { String.class });
					if (debugging) {
						System.err.println("[debug] Properties: " + str2 + " (object from factory)");
					}
					return localMethod.invoke(null, new Object[] { paramString1 });
				} catch (NoSuchMethodException localNoSuchMethodException) {
					if (debugging) {
						System.err.println("[debug] Properties: " + str2 + " (object)");
					}
					return ((Class) localObject).newInstance();
				}
			} catch (ClassNotFoundException localClassNotFoundException) {
				if (debugging) {
					System.err.println("[debug] Properties: " + str2 + " (no class)");
				}
			} catch (Exception localException) {
				System.err.println(
						"[error] Properties: failed to create class \"" + str2 + "\"\n" + localException.toString());
				System.exit(1);
			}
			j++;
		}
		System.err.println("[err] Properties: no class found: \"" + paramString1 + "\"");
		System.exit(1);
		return null;
	}

	public static PropertyDelegate delegate() {
		return theProperties().delegate;
	}

	public static void setDelegate(PropertyDelegate paramPropertyDelegate) {
		theProperties().delegate = paramPropertyDelegate;
	}

}
