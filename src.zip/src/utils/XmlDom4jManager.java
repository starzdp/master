package utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import worldView.world.WorldBody;

/**
 * helper class that parse xml file which from local or internet
 * 
 * @author Danping Zhou
 * @version 6.1.0, 22 Nov 2016
 */
public class XmlDom4jManager {

	private static File inputXml = downLoadFromUrl(SystemParamters.WORLD_VIEW_XML_WEB,
			SystemParamters.DOWNLOAD_FILE_NAME, SystemParamters.DOWNLOAD_FILE_PATH);;

	/**
	 * get world body model from the xml file
	 * 
	 * @param imageName
	 * @param nodeName
	 * @return
	 */
	public static WorldBody getWorldView(String imageName, String nodeName) {
		WorldBody body = new WorldBody();
		if (null == inputXml) {
			InputStream is = XmlDom4jManager.class.getClassLoader().getResourceAsStream(SystemParamters.WORLD_VIEW_XML);
			body = getWorldViewFromLocal(imageName, nodeName, is);
		} else {
			body = getWorldViewFromWeb(imageName, nodeName, inputXml);
		}
		return body;
	}

	/**
	 * get initial world body model from the xml file
	 * 
	 * @return
	 */
	public static WorldBody getInitialViewAndMap() {
		WorldBody body = new WorldBody();
		if (null == inputXml) {
			InputStream is = XmlDom4jManager.class.getClassLoader().getResourceAsStream(SystemParamters.WORLD_VIEW_XML);
			body = getInitialViewAndMapFromLocal(is);
		} else {

			body = getInitialViewAndMapFromWeb(inputXml);
		}
		return body;
	}

	/**
	 * get initial items url list view from xml file
	 * 
	 * @param node
	 * @return
	 */
	public static ArrayList<String> getItemsName(String node) {
		ArrayList<String> itemsName = new ArrayList<String>();
		if (null == inputXml) {
			InputStream is = XmlDom4jManager.class.getClassLoader().getResourceAsStream(SystemParamters.WORLD_VIEW_XML);
			itemsName = getItemsUrlFromLocal(node, is);
		} else {

			itemsName = getItemsUrlFromWeb(node, inputXml);
		}
		return itemsName;
	}

	/**
	 * get world body model from xml file which stored on local
	 * 
	 * @param imageName
	 * @param nodeName
	 * @param inputXml
	 * @return
	 */
	public static WorldBody getWorldViewFromLocal(String imageName, String nodeName, InputStream inputXml) {
		WorldBody body = new WorldBody();
		SAXReader saxReader = new SAXReader();
		try {
			Document document = saxReader.read(inputXml);
			Element root = document.getRootElement();
			Element element = root.element("word");
			Element view = element.element(nodeName);
			Element image = view.element(imageName);
			Attribute front = image.attribute("front");
			Attribute left = image.attribute("left");
			Attribute right = image.attribute("right");
			Attribute back = image.attribute("back");
			Attribute map = image.attribute("map");
			Attribute LocationIsEnable = image.attribute("LocationIsEnable");
			Attribute descirbe = image.attribute("descirbe");

			String suffix = SystemParamters.IMAGE_SUFFIX;
			String worldViewPath = SystemParamters.WORLD_VIEW_PATH;
			String mapUrl = "";
			String frontImageUrl = "";
			String leftImageUrl = "";
			String rightImageUrl = "";
			String backImageUrl = "";
			body.setImageName(imageName);
			if (null != front.getText() & !front.getText().equals("")) {
				frontImageUrl = worldViewPath + front.getText() + suffix;
			}
			if (null != left.getText() & !left.getText().equals("")) {
				leftImageUrl = worldViewPath + left.getText() + suffix;
			}
			if (null != right.getText() & !right.getText().equals("")) {
				rightImageUrl = worldViewPath + right.getText() + suffix;
			}
			if (null != back.getText() & !back.getText().equals("")) {
				backImageUrl = worldViewPath + back.getText() + suffix;
			}
			if (null != map.getText() & !map.getText().equals("")) {
				mapUrl = SystemParamters.MAP_VIEW_PATH + map.getText() + SystemParamters.MAP_SUFFIX;
			}
			body.setFrontImageUrl(frontImageUrl);
			body.setLeftImageUrl(leftImageUrl);
			body.setRightImageUrl(rightImageUrl);
			body.setBackImageUrl(backImageUrl);
			body.setImageDescribe(descirbe.getText());
			body.setMapUrl(mapUrl);

			String[] loactionIsEnableArray = LocationIsEnable.getText().split(",");
			String leftIsenable = loactionIsEnableArray[0].trim();
			String rightIsenable = loactionIsEnableArray[1].trim();
			String frontIsenable = loactionIsEnableArray[2].trim();
			String backIsenable = loactionIsEnableArray[3].trim();
			if (leftIsenable.equals("1")) {
				body.setLeftIsEnabl(true);
			} else {
				body.setLeftIsEnabl(false);
			}
			if (rightIsenable.equals("1")) {
				body.setRightIsEnabl(true);
			} else {
				body.setRightIsEnabl(false);
			}
			if (frontIsenable.equals("1")) {
				body.setFrontIsEnabl(true);
			} else {
				body.setFrontIsEnabl(false);
			}
			if (backIsenable.equals("1")) {
				body.setBackIsEnabl(true);
			} else {
				body.setBackIsEnabl(false);
			}

		} catch (DocumentException e) {
			System.out.println(e.getMessage());
		}
		return body;
	}

	/**
	 * get world body model from xml file which stored on web
	 * 
	 * @param imageName
	 * @param nodeName
	 * @param inputXml
	 * @return
	 */
	public static WorldBody getWorldViewFromWeb(String imageName, String nodeName, File inputXml) {
		WorldBody body = new WorldBody();
		SAXReader saxReader = new SAXReader();
		try {
			Document document = saxReader.read(inputXml);
			Element root = document.getRootElement();
			Element element = root.element("word");
			Element view = element.element(nodeName);
			Element image = view.element(imageName);
			Attribute front = image.attribute("front");
			Attribute left = image.attribute("left");
			Attribute right = image.attribute("right");
			Attribute back = image.attribute("back");
			Attribute map = image.attribute("map");
			Attribute LocationIsEnable = image.attribute("LocationIsEnable");
			Attribute descirbe = image.attribute("descirbe");

			String suffix = SystemParamters.IMAGE_SUFFIX;
			String worldViewPath = SystemParamters.WORLD_VIEW_PATH_WEB;
			String mapUrl = "";
			String frontImageUrl = "";
			String leftImageUrl = "";
			String rightImageUrl = "";
			String backImageUrl = "";
			body.setImageName(imageName);
			if (null != front.getText() & !front.getText().equals("")) {
				frontImageUrl = worldViewPath + front.getText() + suffix;
			}
			if (null != left.getText() & !left.getText().equals("")) {
				leftImageUrl = worldViewPath + left.getText() + suffix;
			}
			if (null != right.getText() & !right.getText().equals("")) {
				rightImageUrl = worldViewPath + right.getText() + suffix;
			}
			if (null != back.getText() & !back.getText().equals("")) {
				backImageUrl = worldViewPath + back.getText() + suffix;
			}
			if (null != map.getText() & !map.getText().equals("")) {
				mapUrl = SystemParamters.MAP_VIEW_PATH_WEB + map.getText() + SystemParamters.MAP_SUFFIX;
			}
			body.setFrontImageUrl(frontImageUrl);
			body.setLeftImageUrl(leftImageUrl);
			body.setRightImageUrl(rightImageUrl);
			body.setBackImageUrl(backImageUrl);
			body.setImageDescribe(descirbe.getText());
			body.setMapUrl(mapUrl);

			String[] loactionIsEnableArray = LocationIsEnable.getText().split(",");
			String leftIsenable = loactionIsEnableArray[0].trim();
			String rightIsenable = loactionIsEnableArray[1].trim();
			String frontIsenable = loactionIsEnableArray[2].trim();
			String backIsenable = loactionIsEnableArray[3].trim();
			if (leftIsenable.equals("1")) {
				body.setLeftIsEnabl(true);
			} else {
				body.setLeftIsEnabl(false);
			}
			if (rightIsenable.equals("1")) {
				body.setRightIsEnabl(true);
			} else {
				body.setRightIsEnabl(false);
			}
			if (frontIsenable.equals("1")) {
				body.setFrontIsEnabl(true);
			} else {
				body.setFrontIsEnabl(false);
			}
			if (backIsenable.equals("1")) {
				body.setBackIsEnabl(true);
			} else {
				body.setBackIsEnabl(false);
			}

		} catch (DocumentException e) {
			System.out.println(e.getMessage());
		}
		return body;
	}

	/**
	 * get initial world body model from xml file which stored on local
	 * 
	 * @param inputXml
	 * @return
	 */
	public static WorldBody getInitialViewAndMapFromLocal(InputStream inputXml) {
		WorldBody initailBodyView = new WorldBody();
		SAXReader saxReader = new SAXReader();
		try {
			Document document = saxReader.read(inputXml);
			Element root = document.getRootElement();
			Element element = root.element("word");
			Element view = element.element("initialView");

			Attribute front = view.attribute("front");
			Attribute left = view.attribute("left");
			Attribute right = view.attribute("right");
			Attribute back = view.attribute("back");
			Attribute imageName = view.attribute("id");
			Attribute map = view.attribute("map");
			Attribute descirbe = view.attribute("descirbe");

			String suffix = SystemParamters.IMAGE_SUFFIX;
			String worldViewPath = SystemParamters.WORLD_VIEW_PATH;
			String mapUrl = SystemParamters.MAP_VIEW_PATH + map.getText() + SystemParamters.MAP_SUFFIX;
			String imageUrl = worldViewPath + imageName.getText() + suffix;
			initailBodyView.setImageName(imageName.getText());
			initailBodyView.setImageDescribe(descirbe.getText());
			if (front.getText() != null & !front.getText().equals("")) {
				String frontImageUrl = worldViewPath + front.getText() + suffix;
				initailBodyView.setFrontImageUrl(frontImageUrl);
			}
			if (left.getText() != null & !left.getText().equals("")) {
				String leftImageUrl = worldViewPath + left.getText() + suffix;
				initailBodyView.setLeftImageUrl(leftImageUrl);
			}
			if (right.getText() != null & !right.getText().equals("")) {
				String rightImageUrl = worldViewPath + right.getText() + suffix;
				initailBodyView.setRightImageUrl(rightImageUrl);
			}
			if (back.getText() != null & !back.getText().equals("")) {
				String backImageUrl = worldViewPath + back.getText() + suffix;
				initailBodyView.setBackImageUrl(backImageUrl);
			}
			initailBodyView.setMapUrl(mapUrl);
			initailBodyView.setImageUrl(imageUrl);

		} catch (DocumentException e) {
			System.out.println(e.getMessage());
		}
		return initailBodyView;
	}

	/**
	 * get initial world body model from xml file which stored on web
	 * 
	 * @param inputXml
	 * @return
	 */
	public static WorldBody getInitialViewAndMapFromWeb(File inputXml) {
		WorldBody initailBodyView = new WorldBody();
		SAXReader saxReader = new SAXReader();
		try {
			Document document = saxReader.read(inputXml);
			Element root = document.getRootElement();
			Element element = root.element("word");
			Element view = element.element("initialView");

			Attribute front = view.attribute("front");
			Attribute left = view.attribute("left");
			Attribute right = view.attribute("right");
			Attribute back = view.attribute("back");
			Attribute imageName = view.attribute("id");
			Attribute map = view.attribute("map");
			Attribute descirbe = view.attribute("descirbe");

			String suffix = SystemParamters.IMAGE_SUFFIX;
			String worldViewPath = SystemParamters.WORLD_VIEW_PATH_WEB;
			String mapUrl = SystemParamters.MAP_VIEW_PATH_WEB + map.getText() + SystemParamters.MAP_SUFFIX;
			String imageUrl = worldViewPath + imageName.getText() + suffix;
			initailBodyView.setImageName(imageName.getText());
			initailBodyView.setImageDescribe(descirbe.getText());
			if (front.getText() != null & !front.getText().equals("")) {
				String frontImageUrl = worldViewPath + front.getText() + suffix;
				initailBodyView.setFrontImageUrl(frontImageUrl);
			}
			if (left.getText() != null & !left.getText().equals("")) {
				String leftImageUrl = worldViewPath + left.getText() + suffix;
				initailBodyView.setLeftImageUrl(leftImageUrl);
			}
			if (right.getText() != null & !right.getText().equals("")) {
				String rightImageUrl = worldViewPath + right.getText() + suffix;
				initailBodyView.setRightImageUrl(rightImageUrl);
			}
			if (back.getText() != null & !back.getText().equals("")) {
				String backImageUrl = worldViewPath + back.getText() + suffix;
				initailBodyView.setBackImageUrl(backImageUrl);
			}
			initailBodyView.setMapUrl(mapUrl);
			initailBodyView.setImageUrl(imageUrl);

		} catch (DocumentException e) {
			System.out.println(e.getMessage());
		}
		return initailBodyView;
	}

	/**
	 * get the items url list from the xml file which stored on local by
	 * iterating the specific node
	 * 
	 * @param nodeName
	 * @return
	 */
	public static ArrayList<String> getItemsUrlFromLocal(String nodeName, InputStream inputXml) {
		ArrayList<String> itemsUrl = new ArrayList<String>();
		SAXReader saxReader = new SAXReader();
		try {
			Document document = saxReader.read(inputXml);
			Element root = document.getRootElement();
			Element element = root.element(nodeName);
			Iterator<Element> it = element.elementIterator();
			while (it.hasNext()) {
				Element e = it.next();
				Attribute name = e.attribute("name");
				String itemName = name.getText().trim() + SystemParamters.ITEMS_SUFFIX;
				String url = SystemParamters.ITEMS_VIEW_PATH + itemName;
				itemsUrl.add(url);
			}
		} catch (DocumentException e) {
			System.out.println(e.getMessage());
		}
		return itemsUrl;

	}

	/**
	 * get the items url list from the xml file which stored on web by iterating
	 * the specific node
	 * 
	 * @param nodeName
	 * @param inputXml
	 * @return
	 */
	public static ArrayList<String> getItemsUrlFromWeb(String nodeName, File inputXml) {
		ArrayList<String> itemsUrl = new ArrayList<String>();
		SAXReader saxReader = new SAXReader();
		try {
			Document document = saxReader.read(inputXml);
			Element root = document.getRootElement();
			Element element = root.element(nodeName);
			Iterator<Element> it = element.elementIterator();
			while (it.hasNext()) {
				Element e = it.next();
				Attribute name = e.attribute("name");
				String itemName = name.getText().trim() + SystemParamters.ITEMS_SUFFIX;
				String url = SystemParamters.ITEMS_VIEW_PATH_WEB + itemName;
				itemsUrl.add(url);
			}
		} catch (DocumentException e) {
			System.out.println(e.getMessage());
		}
		return itemsUrl;

	}

	/**
	 * download xml file from remote web server and store it in a temp dir
	 * @param urlStr
	 * @param fileName
	 * @param savePath
	 * @return
	 */
	public static File downLoadFromUrl(String urlStr, String fileName, String savePath) {
		File saveDir = new File(savePath);
		if (!saveDir.exists()) {
			saveDir.mkdir();
		}
		File file = new File(saveDir + File.separator + fileName);
		try {
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(3 * 1000);
			conn.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");

			InputStream inputStream = conn.getInputStream();
			byte[] getData = readInputStream(inputStream);
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(getData);
			if (fos != null) {
				fos.close();
			}
			if (inputStream != null) {
				inputStream.close();
			}

		} catch (Exception e) {
			// System.out.println(e.getMessage());
			file = null;
		}
		return file;
	}

	/**
	 * read byte from inputStream and store it in byte[]
	 * 
	 * @param inputStream
	 * @return
	 * @throws IOException
	 */
	public static byte[] readInputStream(InputStream inputStream) throws IOException {
		byte[] buffer = new byte[1024];
		int len = 0;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		while ((len = inputStream.read(buffer)) != -1) {
			bos.write(buffer, 0, len);
		}
		bos.close();
		return bos.toByteArray();
	}
}
