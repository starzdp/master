package worldView.world;

/**
 * a model class that store the body image name ,its url, map url and peripheral
 * image's url
 * 
 * @author Danping Zhou
 * @version 6.1.0, 22 Nov 2016
 */
public class WorldBody {

	public String imageName;
	public String imageUrl;
	public String frontImageUrl;
	public String leftImageUrl;
	public String rightImageUrl;
	public String backImageUrl;
	public String mapUrl;
	public String imageDescribe;

	public Boolean frontIsEnabl;
	public Boolean leftIsEnabl;
	public Boolean rightIsEnabl;
	public Boolean backIsEnabl;

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getFrontImageUrl() {
		return frontImageUrl;
	}

	public void setFrontImageUrl(String frontImageUrl) {
		this.frontImageUrl = frontImageUrl;
	}

	public String getLeftImageUrl() {
		return leftImageUrl;
	}

	public void setLeftImageUrl(String leftImageUrl) {
		this.leftImageUrl = leftImageUrl;
	}

	public String getRightImageUrl() {
		return rightImageUrl;
	}

	public void setRightImageUrl(String rightImageUrl) {
		this.rightImageUrl = rightImageUrl;
	}

	public String getBackImageUrl() {
		return backImageUrl;
	}

	public void setBackImageUrl(String backImageUrl) {
		this.backImageUrl = backImageUrl;
	}

	public String getMapUrl() {
		return mapUrl;
	}

	public void setMapUrl(String mapUrl) {
		this.mapUrl = mapUrl;
	}

	public String getImageDescribe() {
		return imageDescribe;
	}

	public void setImageDescribe(String imageDescribe) {
		this.imageDescribe = imageDescribe;
	}

	public Boolean getFrontIsEnabl() {
		return frontIsEnabl;
	}

	public void setFrontIsEnabl(Boolean frontIsEnabl) {
		this.frontIsEnabl = frontIsEnabl;
	}

	public Boolean getLeftIsEnabl() {
		return leftIsEnabl;
	}

	public void setLeftIsEnabl(Boolean leftIsEnabl) {
		this.leftIsEnabl = leftIsEnabl;
	}

	public Boolean getRightIsEnabl() {
		return rightIsEnabl;
	}

	public void setRightIsEnabl(Boolean rightIsEnabl) {
		this.rightIsEnabl = rightIsEnabl;
	}

	public Boolean getBackIsEnabl() {
		return backIsEnabl;
	}

	public void setBackIsEnabl(Boolean backIsEnabl) {
		this.backIsEnabl = backIsEnabl;
	}

}
