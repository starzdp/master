package worldView;
/**
 * A javaFx application main class 
 * @author Danping Zhou
 * @version 6.1.0, 22 Nov 2016
 */
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainProgram extends Application {

	public void start(Stage stage) {

		try {

			FXMLLoader fxmlLoader = new FXMLLoader();
			String viewerFxml = "WorldViewer.fxml";
			BorderPane page = (BorderPane) fxmlLoader.load(this.getClass().getResource(viewerFxml).openStream());
			Scene scene = new Scene(page);
			scene.getStylesheets().add("css/WorldViewStyle.css");
			stage.setTitle("Welcome to Goldshire!");
			stage.setResizable(false);
			stage.setScene(scene);

			WorldController controller = (WorldController) fxmlLoader.getController();
			controller.Initialise();

			stage.show();

		} catch (IOException ex) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
			System.exit(1);
		}
	}

	public static void main(String args[]) {
		launch(args);
	}

}
