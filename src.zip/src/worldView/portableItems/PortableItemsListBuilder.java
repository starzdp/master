package worldView.portableItems;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.image.Image;
import utils.XmlDom4jManager;

/**
 * Helper class that generates list of draggable details Preview, dragged and
 * equipped images for every detail are set here. Currently, dragged and preview
 * images are the same.
 * 
 */
public class PortableItemsListBuilder {
	private List<PortableItem> portableItemList;

	public List<PortableItem> getPortableItemList() {
		if (portableItemList == null) {
			buildPortableItemList();
		}
		return portableItemList;
	}

	/**
	 * create items' image list
	 * 
	 * @param url
	 * @return
	 */
	private Image[] getPortableItems(String url) {
		Image[] portableItems = new Image[3];
		portableItems[0] = new Image(url, 64, 64, false, false);
		portableItems[1] = new Image(url, 64, 64, false, false);
		portableItems[2] = new Image(url, 64, 64, false, false);
		return portableItems;
	}

	/**
	 * get items image url from xml file
	 */
	private void buildPortableItemList() {
		portableItemList = new ArrayList<>();
		ArrayList<String> portableItemNames = XmlDom4jManager.getItemsName("items");
		for (String portableItemName : portableItemNames) {
			PortableItem c = new PortableItem(getPortableItems(portableItemName));
			portableItemList.add(c);
		}
	}

	// private final String []portableItemNames = {
	// "pikachu.png", "jigglypuff.png","charmander.png"
	// };
}
