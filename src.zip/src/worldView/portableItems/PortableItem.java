package worldView.portableItems;

import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import worldView.ImageManager;

/**
 * Class for a draggable detail. Draggable detail has three states: preview,
 * active (dragged), and equipped. Currently, dragged and preview images are the
 * same.
 * 
 * @author Danping Zhou
 * @version 6.1.0, 22 Nov 2016
 */
public class PortableItem {
	private final Image previewImage;
	private final Image activeImage;
	private final Image equippedImage;

	private final ImageView currentImage;

	public void putOn() {
		currentImage.setImage(equippedImage);
	}

	public void takeOff() {
		currentImage.setImage(previewImage);
	}

	private void activate() {
		currentImage.setImage(activeImage);
	}

	public String getImageViewId() {
		return currentImage.getId();
	}

	public Node getNode() {
		return currentImage;
	}

	/**
	 * create items list view and set on drag detected event handler on each
	 * view
	 * 
	 * @param images
	 */
	public PortableItem(Image[] images) {
		this.previewImage = images[0];
		this.activeImage = images[1];
		this.equippedImage = images[2];

		currentImage = new ImageView();
		currentImage.setImage(previewImage);
		String viewId = ImageManager.getImageName(previewImage);
		currentImage.setId(viewId);

		currentImage.setOnDragDetected((MouseEvent event) -> {
			activate();
			Dragboard db = currentImage.startDragAndDrop(TransferMode.MOVE);
			ClipboardContent content = new ClipboardContent();
			content.putString(currentImage.getId());
			db.setContent(content);
			event.consume();
		});
	}
}
