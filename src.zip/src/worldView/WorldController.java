package worldView;

/**
 * A world view controller which can impelement a application like google street view
 * 
 * @author Danping Zhou
 * @version 6.1.0, 22 Nov 2016 
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.ImageCursor;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import utils.SystemParamters;
import utils.XmlDom4jManager;
import worldView.portableItems.PortableItem;
import worldView.portableItems.PortableItemsListBuilder;
import worldView.world.WorldBody;

public class WorldController {

	@FXML
	private TextArea introduction;

	@FXML
	private ImageView imageView;

	@FXML
	private ImageView worldMap;

	@FXML
	private VBox itemPane;

	@FXML
	private Pane bodyPane;

	private HashMap<String, PortableItem> items = new HashMap<>();

	private HashMap<String, ArrayList<ImageView>> worldPortableItems = new HashMap<String, ArrayList<ImageView>>();
	
	// get mouse location
	private ArrayList<Integer> mouseTagLocationLeft = ImageManager.getMouseTagLocation("mouseTag.leftLocation");
	private ArrayList<Integer> mouseTagLocationRight = ImageManager.getMouseTagLocation("mouseTag.rightLocation");
	private ArrayList<Integer> mouseTagLocationFront = ImageManager.getMouseTagLocation("mouseTag.frontLocation");
	private ArrayList<Integer> mouseTagLocationBack = ImageManager.getMouseTagLocation("mouseTag.backLocation");

	double orgSceneX, orgSceneY;
	double orgTranslateX, orgTranslateY;

	private HashMap<String, Image> worldPictureMap = new HashMap<String, Image>();

	/**
	 * initialize the virtual world view interface
	 */
	public void Initialise() {
		// get initialize location view and location from xml file
		WorldBody bodyView = XmlDom4jManager.getInitialViewAndMap();
		
		// set initialize value of textArea and set it uneditable
		introduction.setEditable(false);
		introduction.setText(bodyView.getImageDescribe());

		Image image = new Image(bodyView.getImageUrl(), 600, 400, false, false);
		imageView.setImage(image);

		worldPictureMap.put(bodyView.getImageUrl(), image);

		worldMap.setImage(new Image(bodyView.getMapUrl(), 200, 200, false, false));
		// set mouse event when it in the virtual world
		imageView.setOnMousePressed(imageViewOnMousePressedEventHandler);
		imageView.setOnMouseMoved(imageViewOnMouseMovedEventHandler);

		// create portable items
		populatePortableItem();

		bodyOnDragDetectedEventHandler();

		bodyPane.setOnDragOver(new EventHandler<DragEvent>() {
			@Override
			public void handle(DragEvent event) {
				if (event.getGestureSource() != bodyPane && event.getDragboard().hasString()) {
					event.acceptTransferModes(TransferMode.MOVE);
				}
				event.consume();
			}
		});

		itemPane.setOnDragOver(new EventHandler<DragEvent>() {
			@Override
			public void handle(DragEvent event) {
				if (event.getGestureSource() != itemPane && event.getDragboard().hasString()) {
					event.acceptTransferModes(TransferMode.MOVE);
				}
				event.consume();
			}
		});

		bodyPane.setOnDragDropped(new EventHandler<DragEvent>() {

			@Override
			public void handle(DragEvent event) {
				Dragboard db = event.getDragboard();
				// Get an item ID here, which was stored when the drag started.
				boolean success = false;
				// If this is a meaningful drop...
				if (db.hasString()) {
					String nodeId = db.getString();
					// ...search for the item on body. If it is there...
					ImageView portableItem = (ImageView) itemPane.lookup("#" + nodeId);
					if (portableItem != null) {
						// ... it is removed from body
						// and added to an unequipped container.
						itemPane.getChildren().remove(portableItem);
						bodyPane.getChildren().add(portableItem);
						String imageName = ImageManager.getImageName(imageView);
						ArrayList<ImageView> portableItems = worldPortableItems.get(imageName);
						if (portableItems == null) {
							ArrayList<ImageView> portableItemsNew = new ArrayList<ImageView>();
							portableItemsNew.add(portableItem);
							worldPortableItems.put(imageName, portableItemsNew);
						} else {
							if (!portableItems.contains(portableItem)) {
								portableItems.add(portableItem);
								worldPortableItems.put(imageName, portableItems);
							}
						}
						String describe = ImageManager.getImageName(portableItem);
						setOperateText(describe, SystemParamters.OPERATION_TYPE_0);
						success = true;
					}
				}
				event.setDropCompleted(success);
				event.consume();
			}
		});

		itemPane.setOnDragDropped(new EventHandler<DragEvent>() {

			@Override
			public void handle(DragEvent event) {
				Dragboard db = event.getDragboard();
				// Get an item ID here, which was stored when the drag started.
				boolean success = false;
				// If this is a meaningful drop...
				if (db.hasString()) {
					String nodeId = db.getString();
					// ...search for the item on body. If it is there...
					ImageView portableItem = (ImageView) bodyPane.lookup("#" + nodeId);
					if (portableItem != null) {
						// ... it is removed from body
						// and added to an unequipped container.
						bodyPane.getChildren().remove(portableItem);
						itemPane.getChildren().add(portableItem);
						String imageName = ImageManager.getImageName(imageView);
						ArrayList<ImageView> portableItems = worldPortableItems.get(imageName);
						if (portableItems != null) {
							portableItems.remove(portableItem);
							worldPortableItems.put(imageName, portableItems);
						}
						String describe = ImageManager.getImageName(portableItem);
						setOperateText(describe, SystemParamters.OPERATION_TYPE_1);
						success = true;
					}
				}
				event.setDropCompleted(success);
				event.consume();
			}
		});

	}

	/**
	 * Here portable items are added to items container.
	 */
	private void populatePortableItem() {
		PortableItemsListBuilder portableItemBuilder = new PortableItemsListBuilder();
		if (itemPane == null)
			throw new IllegalStateException("Should call getItems() before populating!");
		List<PortableItem> portableItems = portableItemBuilder.getPortableItemList();
		portableItems.stream().map((c) -> {
			itemPane.getChildren().add(c.getNode());
			itemPane.setPadding(new Insets(0, 0, 0, 15));
			return c;
		}).forEach((c) -> {
			items.put(c.getImageViewId(), c);
		});
	}

	/**
	 * define on mouse pressed event hander which can decide which way is enable and which image should be show on the body container
	 * and give a relative signal
	 */
	EventHandler<MouseEvent> imageViewOnMousePressedEventHandler = new EventHandler<MouseEvent>() {
		@Override
		public void handle(MouseEvent t) {
			String imageName = ImageManager.getImageName(imageView);

			// get around images' url
			String nodeName = imageName.substring(0, 2);
			WorldBody body = XmlDom4jManager.getWorldView(imageName, nodeName);
			String frontImageUrl = body.getFrontImageUrl();
			String rightImageUrl = body.getRightImageUrl();
			String leftImageUrl = body.getLeftImageUrl();
			String backImageUrl = body.getBackImageUrl();

			if (null != frontImageUrl & !"".equals(frontImageUrl)) {
				if (mouseTagLocationFront.get(0) >= t.getX() & t.getX() >= mouseTagLocationFront.get(1)
						& mouseTagLocationFront.get(2) >= t.getY() & t.getY() >= mouseTagLocationFront.get(3)) {
					// make the portableitems which is in the bodypane unvisiable
					makeItemsUnvisible();
					Image frontViewer = getImageFromCache(frontImageUrl);
					imageView.setImage(frontViewer);
					// make the portableitems which is in the bodypane visiable
					makeItemsVisible();
					String descirbe = ImageManager.getLocationDescible(imageView);
					if (!descirbe.equals("") & descirbe != null) {
						setOperateText(descirbe, SystemParamters.OPERATION_TYPE_2);
					}
					setMapView(imageView);

				}
			}
			if (null != rightImageUrl & !"".equals(rightImageUrl)) {
				if (mouseTagLocationRight.get(0) >= t.getX() & t.getX() >= mouseTagLocationRight.get(1)
						& mouseTagLocationRight.get(2) >= t.getY() & t.getY() >= mouseTagLocationRight.get(3)) {
					// make the portableitems which is in the bodypane unvisiable
					makeItemsUnvisible();
					Image rightViewer = getImageFromCache(rightImageUrl);
					imageView.setImage(rightViewer);
					// make the portableitems which is in the bodypane visiable
					makeItemsVisible();
					String descirbe = ImageManager.getLocationDescible(imageView);
					if (!descirbe.equals("") & null != descirbe) {
						setOperateText(descirbe, SystemParamters.OPERATION_TYPE_2);
					}
					setMapView(imageView);
				}

			}
			if (null != leftImageUrl & !"".equals(leftImageUrl)) {
				if (mouseTagLocationLeft.get(0) >= t.getX() & t.getX() >= mouseTagLocationLeft.get(1)
						& mouseTagLocationLeft.get(2) >= t.getY() & t.getY() >= mouseTagLocationLeft.get(3)) {
					// make the portableitems which is in the bodypane unvisiable
					makeItemsUnvisible();
					Image leftViewer = getImageFromCache(leftImageUrl);
					imageView.setImage(leftViewer);
					// make the portableitems which is in the bodypane visiable
					makeItemsVisible();
					String descirbe = ImageManager.getLocationDescible(imageView);
					if (!descirbe.equals("") & descirbe != null) {
						setOperateText(descirbe, SystemParamters.OPERATION_TYPE_2);
					}
					setMapView(imageView);
				}
			}
			if (null != backImageUrl & !"".equals(backImageUrl)) {
				if (mouseTagLocationBack.get(0) >= t.getX() & t.getX() >= mouseTagLocationBack.get(1)
						& mouseTagLocationBack.get(2) >= t.getY() & t.getY() >= mouseTagLocationBack.get(3)) {
					// make the portableitems which is in the bodypane unvisiable
					makeItemsUnvisible();
					Image backViewer = getImageFromCache(backImageUrl);
					imageView.setImage(backViewer);
					// make the portableitems which is in the bodypane visiable
					makeItemsVisible();
					String descirbe = ImageManager.getLocationDescible(imageView);
					if (!descirbe.equals("") & descirbe != null) {
						setOperateText(descirbe, SystemParamters.OPERATION_TYPE_2);
					}
					setMapView(imageView);
				}
			}
		}
	};

	/**
	 * change the mouse cursor when the mouse in different location
	 */
	EventHandler<MouseEvent> imageViewOnMouseMovedEventHandler = new EventHandler<MouseEvent>() {
		@Override
		public void handle(MouseEvent e) {

			String imageName = ImageManager.getImageName(imageView);
			String nodeName = imageName.substring(0, 2);
			WorldBody body = XmlDom4jManager.getWorldView(imageName, nodeName);

			if (mouseTagLocationFront.get(0) >= e.getX() & e.getX() >= mouseTagLocationFront.get(1)
					& mouseTagLocationFront.get(2) >= e.getY() & e.getY() >= mouseTagLocationFront.get(3)
					& body.getFrontIsEnabl()) {
				Image cursorImage = new Image("images/mouseTags/topTag.png", 50, 30, false, false);
				imageView.setCursor(new ImageCursor(cursorImage));
			} else if (mouseTagLocationRight.get(0) >= e.getX() & e.getX() >= mouseTagLocationRight.get(1)
					& mouseTagLocationRight.get(2) >= e.getY() & e.getY() >= mouseTagLocationRight.get(3)
					& body.getRightIsEnabl()) {
				Image cursorImage = new Image("images/mouseTags/rightTag.png", 30, 50, false, false);
				imageView.setCursor(new ImageCursor(cursorImage));
			} else if (mouseTagLocationLeft.get(0) >= e.getX() & e.getX() >= mouseTagLocationLeft.get(1)
					& mouseTagLocationLeft.get(2) >= e.getY() & e.getY() >= mouseTagLocationLeft.get(3)
					& body.getLeftIsEnabl()) {
				Image cursorImage = new Image("images/mouseTags/leftTag.png", 30, 50, false, false);
				imageView.setCursor(new ImageCursor(cursorImage));
			} else if (mouseTagLocationBack.get(0) >= e.getX() & e.getX() >= mouseTagLocationBack.get(1)
					& mouseTagLocationBack.get(2) >= e.getY() & e.getY() >= mouseTagLocationBack.get(3)
					& body.getBackIsEnabl()) {
				Image cursorImage = new Image("images/mouseTags/backTag.png", 50, 30, false, false);
				imageView.setCursor(new ImageCursor(cursorImage));
			} else {
				imageView.setCursor(null);
			}
		}
	};

	/**
	 * create an OnDragDetectedEventHandler on bodyPane
	 * 
	 * @param imageview
	 */
	public void bodyOnDragDetectedEventHandler() {
		for (Iterator iter = items.entrySet().iterator(); iter.hasNext();) {
			Map.Entry element = (Map.Entry) iter.next();
			Object strKey = element.getKey();
			PortableItem itemView = (PortableItem) element.getValue();
			ImageView imageview = (ImageView) itemView.getNode();
			bodyPane.setOnDragDetected(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					Dragboard dragboard = imageview.startDragAndDrop(TransferMode.ANY);
					ClipboardContent content = new ClipboardContent();
					content.putString(imageview.getId());
					dragboard.setContent(content);
				}
			});
		}
	}

	/**
	 * make portableItems which is in the bodypane unvisible
	 */
	public void makeItemsUnvisible() {
		for (Iterator iter = items.entrySet().iterator(); iter.hasNext();) {
			Map.Entry element = (Map.Entry) iter.next();
			PortableItem itemView = (PortableItem) element.getValue();
			if (bodyPane.getChildren().contains((ImageView) itemView.getNode())) {
				((ImageView) itemView.getNode()).setVisible(false);
			}
		}
	}

	/**
	 * make portableItems which is in the bodypane visible
	 */
	public void makeItemsVisible() {
		String imageName1 = ImageManager.getImageName(imageView);
		// 可重用代码
		ArrayList<ImageView> portableItems = worldPortableItems.get(imageName1);
		if (portableItems != null) {
			for (Iterator<ImageView> iter = portableItems.iterator(); iter.hasNext();) {
				iter.next().setVisible(true);
			}
		}
	}

	/**
	 * set the introduction textField content
	 * 
	 * @param describe
	 * @param type
	 */
	public void setOperateText(String describe, String type) {
		String text = introduction.getText();
		if (type.equals(SystemParamters.OPERATION_TYPE_0)) {
			text = "Let the " + describe + " restore its energy here !" + "\n" + text;
		} else if (type.equals(SystemParamters.OPERATION_TYPE_1)) {
			text = "Wow ! ! !" + describe + " is full of energy!" + "\n" + text;
			;
		} else if (type.equals(SystemParamters.OPERATION_TYPE_2)) {
			text = describe + "\n" + text;
			;
		}
		// introduction
		introduction.setText(text);
	}

	/**
	 * show the map of each locations
	 * 
	 * @param imageview
	 */
	public void setMapView(ImageView imageview) {
		String imageName = ImageManager.getImageName(imageView);
		String nodeName = imageName.substring(0, 2);
		WorldBody body = XmlDom4jManager.getWorldView(imageName, nodeName);
		String mapUrl = body.getMapUrl();
		if (!"".equals(mapUrl) & null != mapUrl) {
			worldMap.setImage(new Image(mapUrl, 200, 200, false, false));
		}
	}

	public Image getImageFromCache(String url) {
		Image image = worldPictureMap.get(url);
		if (null == image) {
			image = new Image(url, 600, 400, false, false);
			worldPictureMap.put(url, image);
		}
		return image;
	}
}
