package worldView;

import java.util.ArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import utils.Properties;
import utils.XmlDom4jManager;
import worldView.world.WorldBody;

/**
 * Helper class that manages image resources and provide some method to get
 * information about images
 * 
 * @author Danping Zhou
 * @version 6.1.0, 22 Nov 2016
 */
public class ImageManager {

	public static String getResource(String resource) {
		return ImageManager.class.getResource(resource).toExternalForm();
	}

	public static Image getImage(String image) {
		return new Image(getResource(image));
	}

	/**
	 * get image name
	 * 
	 * @param imageView
	 * @return
	 */
	public static String getImageName(ImageView imageView) {
		String url = imageView.getImage().impl_getUrl();
		String image = url.substring(url.lastIndexOf('/') + 1);
		String imageName = image.substring(0, image.lastIndexOf("."));
		return imageName;

	}

	/**
	 * get image name
	 * 
	 * @param imageView
	 * @return
	 */
	public static String getImageName(Image image) {
		String url = image.impl_getUrl();
		String imagefullname = url.substring(url.lastIndexOf('/') + 1);
		String imageName = imagefullname.substring(0, imagefullname.lastIndexOf("."));
		return imageName;

	}

	/**
	 * get image name which include the suffix, e.g. ".png"
	 * 
	 * @param imageView
	 * @return
	 */
	public static String getImage(ImageView imageView) {
		String url = imageView.getImage().impl_getUrl();
		String image = url.substring(url.lastIndexOf('/') + 1);
		return image;

	}

	/**
	 * get the location describe from properties
	 * 
	 * @param imageView
	 * @return
	 */
	public static String getLocationDescible(ImageView imageView) {
		String imageName = getImageName(imageView);
		String nodeName = imageName.substring(0, 2);
		WorldBody body = XmlDom4jManager.getWorldView(imageName, nodeName);
		return body.getImageDescribe();

	}

	/**
	 * get mouseTag locations
	 * 
	 * @param location
	 * @return
	 */
	public static ArrayList<Integer> getMouseTagLocation(String location) {
		String[] mouselocation = Properties.get(location).split(",");
		;
		ArrayList<Integer> mouseTagLocation = new ArrayList<Integer>();
		for (String coordinate : mouselocation) {
			int coordinateValue = Integer.valueOf(coordinate.trim());
			mouseTagLocation.add(coordinateValue);
		}
		return mouseTagLocation;
	}

}