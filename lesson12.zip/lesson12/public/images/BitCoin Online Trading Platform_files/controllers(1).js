(function () {
    'use strict';

    angular
        .module('app')
        .controller('LoginController', LoginController);

    LoginController.$inject = ['UserService', '$location', '$rootScope', 'FlashService'];
    function LoginController(UserService, $location, $rootScope, FlashService) {
        var vm = this;

        vm.login = login;

        function login() {
            vm.dataLoading = true;
            UserService.GetByEmailPassword(vm.account)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Login successful', true);

                        $rootScope.globals = {
                            currentUser: {
                                email: response.message
                            }
                        };

                        //AuthenticationService.SetCredentials(vm.account.username, vm.account.password);
                        $location.path('/tradeHome');
                    } else {
                        FlashService.error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }
    }

})();
