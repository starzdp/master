/**
 * Created by starzdp on 17/6/13.
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('UserService', UserService);

    UserService.$inject = ['$http'];
    function UserService($http) {
        var service = {};

        service.GetAll = GetAll;
        service.GetById = GetById;
        service.GetByUsername = GetByUsername;
        service.GetByEmailPassword = GetByEmailPassword;
        service.Create = Create;
        service.updatePassword = updatePassword;
        service.Delete = Delete;

        return service;

        function GetAll() {
            return $http.get('/api/users').then(handleSuccess, handleError('Error getting all users'));
        }

        function GetById(id) {
            return $http.get('/api/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
        }

        function GetByUsername(username) {
            return $http.get('/api/users/' + username).then(handleSuccess, handleError('Error getting user by username'));
        }

        function Create(account) {
            return $http.post('/app/create/', account).then(handleSuccess, handleError('Error creating account'));
        }

        function updatePassword(account) {
            return $http.post('/app/update/', account).then(handleSuccess, handleError("Error update password"));
        }

        function Delete(id) {
            return $http.delete('/api/users/' + id).then(handleSuccess, handleError('Error deleting user'));
        }
        function GetByEmailPassword(account) {
            return $http.post('/app/authenticate/',account).then(handleSuccess, handleError('Invalid email or password'));
        }

        // private functions

        function handleSuccess(res) {
            if (res.data === "") {
                return { success: true, message: res.data};
            }else{
                return res.data;
            }
        }

        function handleError(error) {
            return function () {
                return { success: false, message: error };
            };
        }
    }

})();
