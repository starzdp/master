(function () {
    'use strict';

    angular
        .module('app', ['ngRoute', 'ngCookies','validation.match'])
        .config(config)
        .run(run);

    config.$inject = ['$routeProvider', '$locationProvider'];
    function config($routeProvider, $locationProvider) {
        $routeProvider
            .when('/', {
                controller: 'HomeController',
                templateUrl: '/assets/javascripts/home/home.scala.html',
                controllerAs: 'vm'
            })

            .when('/login', {
                controller: 'LoginController',
                templateUrl: '/assets/javascripts/login/login.html',
                controllerAs: 'vm'
            })

            .when('/register', {
                controller: 'RegisterController',
                templateUrl: '/assets/javascripts/register/register.scala.html',
                controllerAs: 'vm'
            })
            .when('/home', {
                controller: 'HomeController',
                templateUrl: '/assets/javascripts/home/home.scala.html',
                controllerAs: 'vm'
            })
            .when('/tradeHome', {
                controller: 'TradeHomeController',
                templateUrl: '/assets/javascripts/transaction/tradeHome.index.html',
                controllerAs: 'vm'
            })
            .when('/trading', {
                controller: 'TradeController',
                templateUrl: '/assets/javascripts/transaction/trading.scala.html',
                controllerAs: 'vm'
            })
            .when('/accountManage', {
                controller: 'AccountManageController',
                templateUrl: '/assets/javascripts/account/passwordReset.scala.html',
                controllerAs: 'vm'
            })
            .otherwise({ redirectTo: '/' });
    }

    run.$inject = ['$rootScope', '$location', '$cookies', '$http'];
    function run($rootScope, $location, $cookies, $http) {
        // keep user logged in after page refresh
        $rootScope.globals = $cookies.getObject('globals') || {};
        if ($rootScope.globals.currentUser) {
            $http.defaults.headers.common.Authorization= 'Basic ' + $rootScope.globals.currentUser.authdata;
        }

        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in and trying to access a restricted page
            var restrictedPage = $.inArray($location.path(), ['/login', '/register','/home','/tradeHome','/accountManage','/trading']) === -1;
            var loggedIn = $rootScope.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                $location.path('/');
            }
        });
    }

})();