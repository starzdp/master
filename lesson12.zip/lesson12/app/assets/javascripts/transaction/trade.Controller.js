(function () {
    'use strict';

    angular
        .module('app')
        .controller('TradeController', TradeController);

    TradeController.$inject = ['UserService', '$rootScope','$scope','FlashService','$location'];
    function TradeController(UserService, $rootScope, $scope,FlashService,$location) {
        var vm = this;

        vm.account = null;
        vm.allTradeInfo = [];
        vm.buyTrading = null;
        vm.buy = buy;
        vm.sell = sell;

        initController();

        function initController() {
            loadCurrentUser();
            loadAllTradingRecords();
        }

        function loadCurrentUser() {
           vm.account = $rootScope.globals.currentUser;
        }

        $scope.totalAmountB = function(){
            var number = $scope.amountB;
            var price = $scope.bidPriceB;

            if(number > 0 && price > 0)
            {
                return number * price;
            }
        };

        $scope.totalAmountS = function(){
            var number = $scope.amountS;
            var price = $scope.bidPriceS;

            if(number > 0 && price > 0)
            {
                return number * price;
            }
        };


        function buy() {
            vm.dataLoading = true;
            var account = vm.account.email;
            var amount = $scope.amountB;
            var bidPrice = $scope.bidPriceB;
            var totalAmount = $scope.amountB*$scope.bidPriceB;
            var type = "buy";
            vm.buyTrading = {
                TradeInfo: {
                    account: account,
                    amount: amount,
                    bidPrice:bidPrice,
                    totalAmount:totalAmount,
                    tradeType:type
                }
            };
            UserService.Trade(vm.buyTrading.TradeInfo)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Doing bitcoin transaction successful', true);
                        $scope.amountB = "";
                        $scope.bidPriceB = "";
                        $scope.passwordB = "";
                        $scope.buyForm.$setPristine();
                        $scope.buyForm.$setUntouched();
                        vm.dataLoading = false;
                        loadAllUsers();
                        // $location.path('/trading');

                    } else {
                        FlashService.error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }

        function sell() {
            vm.dataLoading = true;
            var account = vm.account.email;
            var amount = $scope.amountS;
            var bidPrice = $scope.bidPriceS;
            var type = "sell";
            var totalAmount = $scope.amountS*$scope.bidPriceS;
            vm.buyTrading = {
                TradeInfo: {
                    account: account,
                    amount: amount,
                    bidPrice:bidPrice,
                    totalAmount:totalAmount,
                    tradeType:type
                }
            };
            UserService.Trade(vm.buyTrading.TradeInfo)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Doing bitcoin transaction successful', true);
                        $scope.amountS = "";
                        $scope.bidPriceS = "";
                        $scope.passwordS = "";
                        $scope.sellForm.$setPristine();
                        $scope.sellForm.$setUntouched();
                        vm.dataLoading = false;
                        loadAllUsers();
                        // $location.path('/trading');

                    } else {
                        FlashService.error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }

        function loadAllTradingRecords() {
            UserService.GetAllTradingRecords()
                .then(function (tradingRecords) {
                    vm.allTradeInfo = tradingRecords;
                });
        }

        function deleteUser(id) {
            UserService.Delete(id)
                .then(function () {
                    loadAllUsers();
                });
        }

        function tran_val(val){
            if(parseInt(val)<10){
                val = "0"+val;
            }
            return val;
        }

        function dateFormat(dateTime){
            var dateNew = Date(dateTime);
            var year = dateNew.getFullYear();
            var month = tran_val(dateNew.getMonth()+1);
            var date = tran_val(datenew.getDate());

            var hour=tran_val(datenew.getHours());
            var minute=tran_val(datenew.getMinutes());
            var second=tran_val(datenew.getSeconds());

            var dateStr = year+"-"+month+"-"+date+" "+hour+":"+minute+":"+second;

            return dateStr;
        }
    }

})();
