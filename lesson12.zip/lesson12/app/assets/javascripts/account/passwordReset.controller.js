(function () {
    'use strict';

    angular
        .module('app')
        .controller('AccountManageController', AccountManageController);

    AccountManageController.$inject = ['UserService', '$location', '$rootScope', 'FlashService'];
    function AccountManageController(UserService, $location, $rootScope, FlashService) {
        var vm = this;

        vm.update = update;

        initController();

        function initController() {
            loadCurrentUser();
        }
        function loadCurrentUser() {
            vm.account = $rootScope.globals.currentUser;
        }
        function update() {
            vm.dataLoading = true;
            UserService.updatePassword(vm.account)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('update successful', true);
                        $rootScope.globals = {
                            currentUser: {
                                email: response.message
                            }
                        };
                        //AuthenticationService.SetCredentials(vm.account.username, vm.account.password);
                        $location.path('/tradeHome');
                    } else {
                        FlashService.error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }
    }

})();
