$(document).ready(function() {
    $('#depositForm').bootstrapValidator({
        framework: 'bootstrap',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            depositAmount: {
                validators: {
                    lessThan: {
                        value: 18,
                        message: 'The value must be greater than or equal to 18'
                    }
                }
            }
        }
    });
});

(function () {
    'use strict';

    angular
        .module('app')
        .controller('FinanceGBPController', FinanceGBPController);

    FinanceGBPController.$inject = ['UserService', '$rootScope','$scope','FlashService','$location'];
    function FinanceGBPController(UserService, $rootScope, $scope,FlashService,$location) {
        var vm = this;

        vm.account = null;

        vm.depositTrans = null;
        vm.deposit = deposit;
        vm.withdraw = withdraw;

        initController();

        function initController() {
            loadCurrentUser();
            loadSpecificCurrency();
        }

        function loadCurrentUser() {
            vm.account = $rootScope.globals.currentUser;
        }

        function loadSpecificCurrency() {
            var currencyType = "GBP";
            UserService.GetSpecificCurrency(vm.account.email,currencyType)
                .then(function (currency) {
                    vm.currency = currency;
                });
        }

        function deposit() {
            vm.dataLoading = true;
            var from = cardNumberD.value;
            var to = vm.account.email;
            var amount = depositAmount.value;
            var refId = vm.currency._id;
            var transactionType = "deposit";
            vm.depositTrans = {
                depositInfo: {
                    from: from,
                    to: to,
                    amount: amount,
                    refId: refId,
                    transactionType: transactionType
                }
            };
            UserService.DoTransfer(vm.depositTrans.depositInfo)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Doing bitcoin transaction successful', true);
                        $scope.cardNumberD = "";
                        $scope.depositAmount = "";
                        $scope.depositPw = "";
                        $scope.depositForm.$setPristine();
                        $scope.depositForm.$setUntouched();
                        vm.dataLoading = false;
                        loadSpecificCurrency();
                        // $location.path('/trading');

                    } else {
                        FlashService.error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }

        function withdraw() {
            vm.dataLoading = true;
            var from = vm.account.email;
            var to = cardNumberW.value;
            var amount = withdrawAmount.value;
            var refId = vm.currency._id;
            var transactionType = "withdraw";
            vm.withdrawTrans = {
                withdrawInfo: {
                    from: from,
                    to: to,
                    amount: amount,
                    refId: refId,
                    transactionType: transactionType
                }
            };
            UserService.DoTransfer(vm.withdrawTrans.withdrawInfo)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Doing bitcoin transaction successful', true);
                        $scope.cardNumberW = "";
                        $scope.withdrawAmount = "";
                        $scope.depositPw = "";
                        $scope.withdrawForm.$setPristine();
                        $scope.withdrawForm.$setUntouched();
                        vm.dataLoading = false;
                        loadSpecificCurrency();

                    } else {
                        FlashService.error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }


    }

})();
