/**
 * Created by starzdp on 17/6/13.
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('UserService', UserService);

    UserService.$inject = ['$http'];
    function UserService($http) {
        var service = {};

        service.GetAllTradingRecords = GetAllTradingRecords;
        service.GetById = GetById;
        service.GetByUsername = GetByUsername;
        service.GetByEmailPassword = GetByEmailPassword;
        service.Create = Create;
        service.updatePassword = updatePassword;
        service.Delete = Delete;
        service.Trade = Trade;
        service.GetAccountCurrency = GetAccountCurrency;
        service.GetSpecificCurrency = GetSpecificCurrency;
        service.DoTransfer = DoTransfer;

        return service;

        function GetAllTradingRecords() {
            return $http.get('/app/getTradingRecords/').then(handleSuccess, handleError('Error getting all transactions'));
        }

        function GetAccountCurrency(account) {
            return $http.get('/app/getAccountCurrency/'+ account).then(handleSuccess, handleError('Error getting account currency'));
        }

        function GetSpecificCurrency(email,type) {
            return $http.get('/app/getSpecificCurrency/', {params:{account: email,currencyType:type}}).then(handleSuccess, handleError('Error getting account currency'));
        }

        function GetById(id) {
            return $http.get('/api/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
        }

        function GetByUsername(username) {
            return $http.get('/api/users/' + username).then(handleSuccess, handleError('Error getting user by username'));
        }

        function Create(account) {
            return $http.post('/app/create/', account).then(handleSuccess, handleError('Error creating account'));
        }

        function updatePassword(account) {
            return $http.post('/app/update/', account).then(handleSuccess, handleError("Error update password"));
        }

        function Delete(id) {
            return $http.delete('/api/users/' + id).then(handleSuccess, handleError('Error deleting user'));
        }
        function GetByEmailPassword(account) {
            return $http.post('/app/authenticate/',account).then(handleSuccess, handleError('Invalid email or password'));
        }

        function Trade(tradeInfo) {
            return $http.post('/app/DoTrading/', tradeInfo).then(handleSuccess, handleError('Error do trading'));
        }

        function DoTransfer(transferInfo) {
            return $http.post('/app/DoTransfer/', transferInfo).then(handleSuccess, handleError('Error do trading'));
        }

        // private functions

        function handleSuccess(res) {
            if (res.data === "") {
                return { success: true, message: res.data};
            }else{
                return res.data;
            }
        }

        function handleError(error) {
            return function () {
                return { success: false, message: error };
            };
        }
    }

})();
