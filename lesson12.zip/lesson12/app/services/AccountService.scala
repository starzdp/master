package services

import javax.inject.Inject

import dao.AccountDao
import models._
import models.Account._
/**
  * Created by starzdp on 17/6/21.
  */
class AccountService@Inject()(accountDao: AccountDao) {

  def save(account:Account) = accountDao.save(account)

}
