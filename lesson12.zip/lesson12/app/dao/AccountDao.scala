package dao
import scala.concurrent.Future
import models._
import models.Account._
import java.util.UUID
import scala.concurrent.Future

import play.api.Play.current
import play.api.libs.concurrent.Execution.Implicits.defaultContext
import play.api.libs.json._

import play.modules.reactivemongo.ReactiveMongoApi
import play.modules.reactivemongo.json._
import play.modules.reactivemongo.json.collection.JSONCollection



/**
  * Created by starzdp on 17/6/21.
  */
trait AccountDao {
  def save(account:Account):Future[Account]
}

class AccountMongoDao extends AccountDao{
  lazy val reactiveMongoApi = current.injector.instanceOf[ReactiveMongoApi]
  val accounts = reactiveMongoApi.db.collection[JSONCollection]("account")

  def save(account:Account):Future[Account] =
    accounts.insert(account).map(_ => account)
}
