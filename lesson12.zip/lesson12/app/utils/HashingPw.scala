package utils
import org.mindrot.jbcrypt.BCrypt

/**
  * Created by starzdp on 17/6/21.
  */
object HashingPw {

  def getHash(str: String) : String = {
    BCrypt.hashpw(str, BCrypt.gensalt())
  }
  def checkHash(str: String, strHashed: String): Boolean = {
    BCrypt.checkpw(str,strHashed)
  }

}
