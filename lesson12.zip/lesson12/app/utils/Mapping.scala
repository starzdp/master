package utils

import play.api.data.Forms._
import org.mindrot.jbcrypt.BCrypt._
import java.util.UUID
/**
  * Created by starzdp on 17/6/21.
  */
object Mapping {

  val password = nonEmptyText.transform[String](
    hashpw(_, gensalt(12)),
    (s:String) => s
  )
  val uuid = java.util.UUID.randomUUID.toString

}
