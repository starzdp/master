package models

import org.joda.time.DateTime
import org.mindrot.jbcrypt.BCrypt.checkpw
import play.api.Play.current
import play.api.data._
import play.api.data.Forms._
import play.api.data.Forms.{mapping, of, optional}
import play.api.data.validation.Constraints.pattern
import play.api.libs.functional.syntax.unlift
import play.api.libs.json._
import play.modules.reactivemongo.ReactiveMongoApi
import play.modules.reactivemongo.json.collection.JSONCollection
import play.api.libs.functional.syntax._
import play.api.data.format.Formats._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{Await, ExecutionContext, Future}
import play.modules.reactivemongo.json._
import com.typesafe.config.ConfigFactory
import models.Account.collection

import scala.concurrent.duration.Duration



/**
  * Created by starzdp on 17/7/06.
  */

case class AccountCurrency(
                            id:Option[String],
                            account : String,
                            accountType : String,
                            amount : BigDecimal,
                            frozenAmount : BigDecimal,
                            createDate:Option[DateTime],
                            updateDate:Option[DateTime]
                   )


object AccountCurrency{
  lazy val reactiveMongoApi = current.injector.instanceOf[ReactiveMongoApi]
  val collection = reactiveMongoApi.db.collection[JSONCollection]("accountCurrency")

/**
  // Example reads
  implicit val reads: Reads[AccountCurrency] = (
    (JsPath \ "account").read[String] and
      (JsPath \ "accountType").read[String] and
      (JsPath \ "amount").read[BigDecimal] and
      (JsPath \ "frozenAmount").read[BigDecimal]
    )(AccountCurrency.apply _)

  // Example writes
  implicit val writes: Writes[AccountCurrency] = (
    (JsPath \ "_id").write[String] and
    (JsPath \ "account").write[String] and
      (JsPath \ "accountType").write[String] and
      (JsPath \ "amount").write[BigDecimal] and
        (JsPath \ "frozenAmount").write[BigDecimal]
    )(unlift(AccountCurrency.unapply _))

  implicit object writes extends OWrites[AccountCurrency] {
    def writes(accountCurrency : AccountCurrency): JsObject = Json.obj(
      "_id" -> accountCurrency.id,
      "account" -> accountCurrency.account,
      "accountType" -> accountCurrency.accountType,
      "amount" -> accountCurrency.amount,
      "frozenAmount" -> accountCurrency.frozenAmount)
  }
*/

  implicit object reads extends Reads[AccountCurrency] {
    def reads(json: JsValue): JsResult[AccountCurrency] = json match {
      case obj: JsObject => try {
        val id = (obj \ "_id").asOpt[String]
        val account = (obj \ "account").as[String]
        val accountType = (obj \ "accountType").as[String]
        val amount = (obj \ "amount").as[BigDecimal]
        val frozenAmount = (obj \ "frozenAmount").as[BigDecimal]
        val createDate = (obj \ "createDate").asOpt[Long]
        val updateDate = (obj \ "updateDate").asOpt[Long]

        JsSuccess(AccountCurrency(id, account, accountType, amount,frozenAmount, createDate.map(new DateTime(_)),
          updateDate.map(new DateTime(_))))

      } catch {
        case cause: Throwable => JsError(cause.getMessage)
      }

      case _ => JsError("expected.jsobject")
    }
  }

  implicit object writes extends OWrites[AccountCurrency] {
    def writes(accountCurrency: AccountCurrency): JsObject = Json.obj(
      "_id" -> accountCurrency.id,
      "account" -> accountCurrency.account,
      "accountType" -> accountCurrency.accountType,
      "amount" -> accountCurrency.amount,
      "frozenAmount" ->accountCurrency.frozenAmount,
      "createDate" -> accountCurrency.createDate.fold(-1L)(_.getMillis),
      "updateDate" -> accountCurrency.updateDate.fold(-1L)(_.getMillis))
  }

  val form = Form(
    mapping(
      "id" -> optional(of[String] verifying pattern(
        """[a-fA-F0-9]{24}""".r,
        "constraint.objectId",
        "error.objectId")),
      "account" -> text,
      "accountType" -> text,
      "amount" -> bigDecimal,
      "frozenAmount" -> bigDecimal,
      "createDate" -> optional(of[Long]),
      "updateDate" -> optional(of[Long])
    ) { (id, account, accountType, amount,frozenAmount,createDate, updateDate) =>
      AccountCurrency(
        id,
        account,
        accountType,
        amount,
        frozenAmount,
        createDate.map(new DateTime(_)),
        updateDate.map(new DateTime(_)))
    } { accountCurrency =>
      Some(
        (accountCurrency.id,
          accountCurrency.account,
          accountCurrency.accountType,
          accountCurrency.amount,
          accountCurrency.frozenAmount,
          accountCurrency.createDate.map(_.getMillis),
          accountCurrency.updateDate.map(_.getMillis)))
    }
  )



  def findAccountCurrencyById(id:String) = {
    Await.result( collection.find(Json.obj(
      "_id"->id
    )).one[AccountCurrency], Duration.Inf)
  }


  def updateAccountCurrency(id:String, amount:BigDecimal) = {

    var transferAmount:BigDecimal = 0

    val accountCurrency = findAccountCurrencyById(id)
    if(accountCurrency.isEmpty){
      JsError("The transfer account is not exist!")
    }else{
      transferAmount = accountCurrency.get.amount + amount
    }
    collection.update(Json.obj(
      "_id" -> id
    ),Json.obj(
      "$set" -> Json.obj("amount"-> transferAmount,"updateDate" -> new DateTime())
    ))
  }
}