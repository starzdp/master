package models

import java.util.UUID

import play.api.Play.current
import reactivemongo.bson.{BSONDocument, BSONDocumentReader, BSONDocumentWriter, BSONObjectID, BSONReader, BSONString, BSONWriter}
import play.api.libs.json.{JsPath, Json, Reads}
import sun.security.util.Password
import play.api.libs.functional.syntax._
import utils._
import utils.HashingPw._
import play.modules.reactivemongo.ReactiveMongoApi
import play.modules.reactivemongo.json.collection.JSONCollection
//import reactivemongo.api.collections.bson.BSONCollection
import play.modules.reactivemongo.json.ImplicitBSONHandlers._
import reactivemongo.bson.DefaultBSONHandlers._

import concurrent.ExecutionContext.Implicits.global
import concurrent.Await
import concurrent.duration.Duration
import play.api.Play.current
import play.api.data._
import play.api.data.Forms._
import utils.Mapping._
import utils.Mapping.uuid

import scala.concurrent.{ExecutionContext, Future}
import org.mindrot.jbcrypt.BCrypt._
import play.api.libs.json._
import play.modules.reactivemongo.json.BSONFormats._
import scala.collection.convert.WrapAsScala._


/**
  * Created by starzdp on 17/6/13.
  */

case class Account (
                     accountId:String,
                     email : String,
                     password : String
                   )

object Account{

  lazy val reactiveMongoApi = current.injector.instanceOf[ReactiveMongoApi]
  val collection = reactiveMongoApi.db.collection[JSONCollection]("account")

  /*
  ## findAccountByEmail

  used to search the collection in mongodb for an account that matching this particular email (as the email can uniquely
  identify account)
 */
  def findAccountByEmail(email:String) = {
    Await.result( collection.find(Json.obj(
      "email"->email
    )).one[Account], Duration.Inf)
  }

  def findAccountByEmailHasR(email:String):Future[Option[Account]] = {
    collection.find(Json.obj(
      "email"->email
    )).one[Account]
  }
  /*
    ## findAccountById

    used to search the collection in mongodb for an account that matching this particular id
    The `id` property is a `String` that will get coerced into a `BSONObjectID`


  def findAccountById(id:String) ={
    collection.find(Json.obj(
      "_id" -> BSONObjectID(id)
    )).one[Account]
  }
 */

  /*
    ## authenticate

    Takes a email and password mapping and checks for existence and correct password against the
    mongo collection.  At no point are we storing a plain text or obfuscated password.  Its
    all encrypted using the slow but ultra string BCrypt
  */
  def authenticate(email:String, password: String) = {

    val check = collection.find(Json.obj(
      "email" -> email
    )).one[Account].map(maybeAccount =>
      maybeAccount match {
        case Some(_) if (checkpw(password, maybeAccount.get.password)) => maybeAccount
        case _ => None
      }
    )
    Await.result(check, Duration Inf)
  }

  /*
    implicit object AccountReaderFormat extends BSONDocumentReader[Account] {
      def read(doc: BSONDocument): Account = {
        val id = doc.getAs[BSONObjectID]("_id")
        val email = doc.getAs[String]("email").get
        val password = doc.getAs[String]("password").get

        Account(id, email, password)
      }
    }
     implicit object AccountWriteFormat extends BSONDocumentWriter[Account]{
      def write(account: Account): BSONDocument =
        BSONDocument("_id" -> account.id.getOrElse(BSONObjectID.generate),
          "email" -> BSONString(account.email), "password" -> BSONString(account.password))
    }
   */

  // Example reads
  implicit val AccountReads: Reads[Account] = (
      (JsPath \ "accountId").read[String] and
      (JsPath \ "email").read[String] and
      (JsPath \ "password").read[String]

    )(Account.apply _)

  // Example writes
  implicit val writes: Writes[Account] = (
      (JsPath \ "accountId").write[String] and
      (JsPath \ "email").write[String] and
      (JsPath \ "password").write[String]
    )(unlift(Account.unapply _))


  val form  = Form(
    mapping(
      "accountId"  -> text,
      "email"      -> email,
      "password"   -> password
    )(Account.apply _)
    (Account.unapply _) verifying(
      "Account already exists for this user" , { account =>
      Account.findAccountByEmail(account.email).isEmpty
    })
  )

  val passwordResetForm = Form(
    "password" -> password
  )

  val loginForm = Form(
    mapping(
      "email"    -> email,
      "password" -> text
    )(Account.authenticate)
    (_.map(u => (u.email, ""))) verifying (
      "Invalid email or password",
      result => result.isDefined
    )
  )

  implicit val AccountFormat = Json.format[Account]
}
