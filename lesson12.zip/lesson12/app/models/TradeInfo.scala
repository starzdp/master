package models
import org.joda.time.DateTime
import play.api.Play.current
import play.api.libs.json.Json
import play.modules.reactivemongo.ReactiveMongoApi
import play.modules.reactivemongo.json.collection.JSONCollection
import reactivemongo.bson._
import play.api.data._
import play.api.data.Forms._
import play.api.data.validation.Constraints._
import play.modules.reactivemongo.json.BSONFormats._
import play.api.data.format.Formats._
import reactivemongo.bson.BSONObjectID._
import play.api.libs.json.{JsPath, Json, Reads}
import org.joda.time.DateTime
import play.api.data._
import play.api.data.Forms.{longNumber, mapping, nonEmptyText, optional, text}
import play.api.data.validation.Constraints.pattern
import reactivemongo.bson.{BSONDateTime, BSONDocument, BSONObjectID}
import play.api.libs.json._
import play.api.libs.json.{JsObject, JsString, Json}
import play.modules.reactivemongo.json._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
/**
  * Created by starzdp on 17/6/26.
  */

case class TradeInfo (
                     id:Option[String],
                     account: String,
                     bidPrice : BigDecimal,
                     amount : BigDecimal,
                     totalAmount:BigDecimal,
                     tradeType :String,
                     createDate:Option[DateTime],
                     updateDate:Option[DateTime]
                   )

object TradeInfo{
  lazy val reactiveMongoApi = current.injector.instanceOf[ReactiveMongoApi]
  val collection = reactiveMongoApi.db.collection[JSONCollection]("tradeInfo")

  implicit object TradeInfoWrites extends OWrites[TradeInfo] {
    def writes(tradeInfo: TradeInfo): JsObject = Json.obj(
      "_id" -> tradeInfo.id,
      "account" -> tradeInfo.account,
      "bidPrice" -> tradeInfo.bidPrice,
      "amount" -> tradeInfo.amount,
      "totalAmount" ->tradeInfo.totalAmount,
      "tradeType" ->tradeInfo.tradeType,
      "createDate" -> tradeInfo.createDate.fold(-1L)(_.getMillis),
      "updateDate" -> tradeInfo.updateDate.fold(-1L)(_.getMillis))
  }

  implicit object TradeInfoReads extends Reads[TradeInfo] {
    def reads(json: JsValue): JsResult[TradeInfo] = json match {
      case obj: JsObject => try {
        val id = (obj \ "_id").asOpt[String]
        val account = (obj \ "account").as[String]
        val bidPrice = (obj \ "bidPrice").as[BigDecimal]
        val amount = (obj \ "amount").as[BigDecimal]
        val totalAmount = (obj \ "totalAmount").as[BigDecimal]
        val tradeType = (obj \ "tradeType").as[String]
        val createDate = (obj \ "createDate").asOpt[Long]
        val updateDate = (obj \ "updateDate").asOpt[Long]

        JsSuccess(TradeInfo(id, account, bidPrice, amount,totalAmount,tradeType,
          createDate.map(new DateTime(_)),
          updateDate.map(new DateTime(_))))

      } catch {
        case cause: Throwable => JsError(cause.getMessage)
      }

      case _ => JsError("expected.jsobject")
    }
  }

  val form = Form(
    mapping(
      "id" -> optional(of[String] verifying pattern(
        """[a-fA-F0-9]{24}""".r,
        "constraint.objectId",
        "error.objectId")),
      "account" -> text,
      "bidPrice" -> bigDecimal,
      "amount" -> bigDecimal,
      "totalAmount" -> bigDecimal,
      "tradeType" -> text,
      "createDate" -> optional(of[Long]),
      "updateDate" -> optional(of[Long])
    ) { (id, account, bidPrice, amount,totalAmount,tradeType, createDate, updateDate) =>
      TradeInfo(
        id,
        account,
        bidPrice,
        amount,
        totalAmount,
        tradeType,
        createDate.map(new DateTime(_)),
        updateDate.map(new DateTime(_)))
    } { tradeInfo =>
      Some(
        (tradeInfo.id,
          tradeInfo.account,
          tradeInfo.bidPrice,
          tradeInfo.amount,
          tradeInfo.totalAmount,
          tradeInfo.tradeType,
          tradeInfo.createDate.map(_.getMillis),
          tradeInfo.updateDate.map(_.getMillis)))
    }
  )

  def findTradeInfoByType(tradeType:String)= {

    // the cursor of documents
    collection.find(Json.obj(
      "$orderby" -> Json.obj("createDate" -> -1),
      "$query" -> Json.obj("tradeType" -> tradeType))).cursor[TradeInfo]
  }
}