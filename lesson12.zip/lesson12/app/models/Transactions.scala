package models
import org.joda.time.DateTime
import play.api.Play.current
import play.api.data._
import play.api.data.Forms._
import play.api.data.Forms.{mapping, of, optional}
import play.api.libs.json._
import play.modules.reactivemongo.ReactiveMongoApi
import play.modules.reactivemongo.json.collection.JSONCollection
import play.api.data.validation.Constraints.pattern
import play.api.data.format.Formats._

/**
  * Created by starzdp on 17/7/11.
  */
case class Transactions (
                        id:Option[String],
                        from:String,
                        to : String,
                        amount : BigDecimal,
                        transactionType :String,
                        createDate:Option[DateTime],
                        updateDate:Option[DateTime],
                        refId:String
                        )


object Transactions{

  lazy val reactiveMongoApi = current.injector.instanceOf[ReactiveMongoApi]
  val collection = reactiveMongoApi.db.collection[JSONCollection]("transactions")

  implicit object TransactionsWrites extends OWrites[Transactions] {
    def writes(transactions: Transactions): JsObject = Json.obj(
      "_id" -> transactions.id,
      "from" -> transactions.from,
      "to" -> transactions.to,
      "amount" -> transactions.amount,
      "transactionType" -> transactions.transactionType,
      "createDate" -> transactions.createDate.fold(-1L)(_.getMillis),
      "updateDate" -> transactions.updateDate.fold(-1L)(_.getMillis),
      "refId" -> transactions.refId)
  }

  implicit object TransactionsReads extends Reads[Transactions] {
    def reads(json: JsValue): JsResult[Transactions] = json match {
      case obj: JsObject => try {
        val id = (obj \ "_id").asOpt[String]
        val from = (obj \ "from").as[String]
        val to = (obj \ "to").as[String]
        val amount = (obj \ "amount").as[BigDecimal]
        val transactionType = (obj \ "transactionType").as[String]
        val createDate = (obj \ "createDate").asOpt[Long]
        val updateDate = (obj \ "updateDate").asOpt[Long]
        var refId =(obj \ "refId").as[String]

        JsSuccess(Transactions(id, from, to, amount,transactionType, createDate.map(new DateTime(_)),
          updateDate.map(new DateTime(_)),refId))

      } catch {
        case cause: Throwable => JsError(cause.getMessage)
      }

      case _ => JsError("expected.jsobject")
    }
  }

  val form = Form(
    mapping(
      "id" -> optional(of[String] verifying pattern(
        """[a-fA-F0-9]{24}""".r,
        "constraint.objectId",
        "error.objectId")),
      "from" -> text,
      "to" -> text,
      "amount" -> bigDecimal,
      "transactionType" -> text,
      "createDate" -> optional(of[Long]),
      "updateDate" -> optional(of[Long]),
      "refId" -> text
    ) { (id, from, to, amount,transactionType, createDate, updateDate,refId) =>
      Transactions(
        id,
        from,
        to,
        amount,
        transactionType,
        createDate.map(new DateTime(_)),
        updateDate.map(new DateTime(_)),refId)
    } { transactions =>
      Some(
        (transactions.id,
          transactions.from,
          transactions.to,
          transactions.amount,
          transactions.transactionType,
          transactions.createDate.map(_.getMillis),
          transactions.updateDate.map(_.getMillis),
          transactions.refId))
    }
  )

}