package models

import play.api.libs.json.Json


/**
  * Created by starzdp on 17/6/13.
  */
case class User(
                 email : String,
                 oldPassword : String,
                 newPassword : String
                   )


object User{
  implicit val AccountFormat = Json.format[User]
}


