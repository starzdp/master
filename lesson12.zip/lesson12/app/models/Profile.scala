package models
import play.api.libs.json.{JsPath, Json, Reads}

/**
  * Created by starzdp on 17/7/11.
  */
case class Profile(
                    email : String,
                    password : String
                  )

object Profile{
  implicit val ProfileFormat = Json.format[Profile]
}
