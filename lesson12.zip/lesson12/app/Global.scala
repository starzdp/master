/**
  * Created by starzdp on 17/6/28.
  */
import models._
import play.api.Play.current
import play.api._
import play.api.libs.concurrent.Execution.Implicits._
import play.api.libs.concurrent._

import scala.concurrent.duration._
import scala.concurrent.Future
import reactivemongo.api.Cursor
import play.api.libs.json._
import models._
import models.TradeInfo._

object Global extends GlobalSettings {

  override def onStart(app: Application) {
    Logger.info("Application has started")
    startTransactionAnto
  }

  override def onStop(app: Application) {
    Logger.info("Application shutdown...")
  }

  def startTransactionAnto = {
    Akka.system.scheduler.schedule(5 seconds, 5 seconds) {
        //find buy transactions
      val list: Future[List[TradeInfo]] = TradeInfo.findTradeInfoByType("buy").collect[List]()
      for(trade <- list){
          println(trade)
      }

      val futurePersonsJsonArray: Future[JsArray] = list.map { tradeInfo =>
        Json.arr(tradeInfo)
      }



    }
  }
}