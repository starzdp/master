package controllers

import javax.inject.{Inject, Singleton}

import models.Account
import play.api._
import play.api.mvc._
import play.api.libs.json._
import play.api.libs.json.JsPath
import play.api.libs.json.Json.toJson
import play.api.libs.json.Reads
import play.api.libs.json.Reads._
import play.api.libs.json.Reads.StringReads
import play.api.libs.json.Reads.functorReads

import scala.concurrent.Future
import play.api.libs.concurrent.Execution.Implicits.defaultContext
import play.modules.reactivemongo._
import play.modules.reactivemongo.json.collection.JSONCollection


/**
  * Created by starzdp on 17/6/13.
  */
@Singleton
class Application @Inject() (val reactiveMongoApi: ReactiveMongoApi) extends Controller
with MongoController with ReactiveMongoComponents{
  def index = Action{
    Ok(views.html.index())
  }
  def collection: JSONCollection = db.collection[JSONCollection]("users")

  import models._
  import models.User._


  def create = Action.async(parse.json) { request =>
    /*
     * request.body is a JsValue.
     * There is an implicit Writes that turns this JsValue as a JsObject,
     * so you can call insert() with this JsValue.
     * (insert() takes a JsObject as parameter, or anything that can be
     * turned into a JsObject using a Writes.)
     */
    request.body.validate[User].map { user =>
      // `post` is an instance of the case class `models.User`
      collection.insert(user).map { lastError =>
        Logger.debug(s"Successfully inserted with LastError: $lastError")
        Created(s"success")
      }
    }.getOrElse(Future.successful(BadRequest("invalid json")))
  }

  // Handles the username-password sent as JSON:



}

