package controllers

import javax.inject.{Inject, Singleton}

import play.api._
import play.api.data.Forms._
import play.api.data._
import play.api.libs.concurrent.Execution.Implicits.defaultContext
import play.api.libs.json.{JsError, JsObject, JsString, Json}
import play.api.mvc._
import play.modules.reactivemongo._
import play.modules.reactivemongo.json._
import play.modules.reactivemongo.json.collection.JSONCollection

import scala.concurrent.Future
import org.joda.time.DateTime
import java.util.UUID

import models.AccountCurrency


/**
  * Created by starzdp on 17/6/13.
  */
@Singleton
class TradingApplication extends Controller {


  import models.TradeInfo._
  import models._
  import models.AccountCurrency._
  def DoTrading = Action.async(parse.json){ implicit request =>
    /*
     * request.body is a JsValue.
     * There is an implicit Writes that turns this JsValue as a JsObject,
     * so you can call insert() with this JsValue.
     * (insert() takes a JsObject as parameter, or anything that can be
     * turned into a JsObject using a Writes.)
     */

    TradeInfo.form.bindFromRequest.fold(
      errors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s" Do trading error")))),

      // if no error, then insert the trading recordes into the 'tradeInfo' collection
      tradeInfo => TradeInfo.collection.insert(tradeInfo.copy(
        id = tradeInfo.id.orElse(Some(UUID.randomUUID().toString)),
        createDate = Some(new DateTime()),
        updateDate = Some(new DateTime()))
      ).map{lastError =>
        Logger.debug(s"Successfully inserted with LastError: $lastError")
        Created
      }
    )

  }

  // list all trading records and sort them by createDate desc
  def getTradingRecords = Action.async { implicit request =>
    // get a sort document (see getSort method for more information)
   // val sort: Option[JsObject] = getSort(request)

    // build a selection document with an empty query and a sort subdocument ('$orderby')
    val query = Json.obj(
      "$orderby" -> Json.obj( "createDate" -> -1 ),
      "$query" -> Json.obj())

    val activeSort = request.queryString.get("sort").
      flatMap(_.headOption).getOrElse("none")

    // the cursor of documents
    val found = TradeInfo.collection.find(query).cursor[TradeInfo]
    // build (asynchronously) a list containing all the articles
    found.collect[List]().map { transactions =>
      Ok(Json.toJson(transactions))
    }.recover {
      case e =>
        e.printStackTrace()
        BadRequest(e.getMessage())
    }
  }

  def DoTransferTransactions = Action.async(parse.json){ implicit request =>
    /*
     * request.body is a JsValue.
     * There is an implicit Writes that turns this JsValue as a JsObject,
     * so you can call insert() with this JsValue.
     * (insert() takes a JsObject as parameter, or anything that can be
     * turned into a JsObject using a Writes.)
     */

    Transactions.form.bindFromRequest.fold(
      errors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s"Account already exists for this user")))),

      // if no error, then insert the article into the 'articles' collection
      transaction => Transactions.collection.insert(transaction.copy(
        id = transaction.id.orElse(Some(UUID.randomUUID().toString)),
        createDate = Some(new DateTime()),
        updateDate = Some(new DateTime()))
      ).map{lastError =>
        Logger.debug(s"Successfully inserted with LastError: $lastError")
        var amount:BigDecimal = 0
        if(transaction.transactionType.equals("withdraw")){
          amount = 0 - transaction.amount
        }else if(transaction.transactionType.equals("deposit")){
          amount = transaction.amount
        }else{
          Left("Wrong transfer type")
        }
        AccountCurrency.updateAccountCurrency(transaction.refId, amount)
        Created
      }
    )

  }

  private def getSort(request: Request[_]): Option[JsObject] =
    request.queryString.get("sort").map { fields =>
      val sortBy = for {
        order <- fields.map { field =>
          if (field.startsWith("-"))
            field.drop(1) -> -1
          else field -> 1
        }
        if order._1 == "creationDate"
      } yield order._1 -> implicitly[Json.JsValueWrapper](Json.toJson(order._2))

      Json.obj(sortBy: _*)
    }

}

