package controllers

import java.util.UUID
import javax.inject.{Inject, Singleton}

import org.joda.time.DateTime
import play.api._
import play.api.libs.concurrent.Execution.Implicits.defaultContext
import play.api.mvc._
import play.modules.reactivemongo._
import play.modules.reactivemongo.json.collection.JSONCollection

import scala.concurrent.Future
import play.api.libs.json.{JsArray, JsError, JsValue, Json}
import play.modules.reactivemongo.json._
import play.api.data._
import play.api.data.Forms._




/**
  * Created by starzdp on 17/6/13.
  */
@Singleton
class AccountApplication @Inject()(val reactiveMongoApi: ReactiveMongoApi) extends Controller
with MongoController with ReactiveMongoComponents{

  def loginForm = Form(
    tuple(
      "email" -> email,
      "password" -> text(minLength = 6, maxLength = 10)
    )
  )

  def index = Action{
    Ok(views.html.index())
  }

  def collection: JSONCollection = db.collection[JSONCollection]("account")

  import models.Account._
  import models._
  import models.Account.form

  /*
     * request.body is a JsValue.
     * There is an implicit Writes that turns this JsValue as a JsObject,
     * so you can call insert() with this JsValue.
     * (insert() takes a JsObject as parameter, or anything that can be
     * turned into a JsObject using a Writes.)
   */

  def create = Action.async{ implicit request =>
    val account = request.body.asInstanceOf[AnyContentAsJson].json.as[Profile]
    val anyData = Map("accountId"->java.util.UUID.randomUUID.toString,"email" -> account.email, "password" -> account.password)
    val btc,rmb,usd,eur,gbp:BigDecimal = 0

    Account.form.bind(anyData).fold(
      formWithErrors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s"Account already exists for this user")))),
      account => {
        Account.collection.insert(account).map { lastError =>
          Logger.debug(s"Successfully inserted with LastError: $lastError")
          Created
        }

        val currencyBTC = Map("account"-> account.email, "accountType"-> "BTC","amount"-> "0","frozenAmount" -> "0")
        AccountCurrency.form.bind(currencyBTC).fold(
          errors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s" Creating BTC currency account error")))),

          accountCurrency => AccountCurrency.collection.insert(accountCurrency.copy(
            id = accountCurrency.id.orElse(Some(UUID.randomUUID().toString)),
            createDate = Some(new DateTime()),
            updateDate = Some(new DateTime()))
          ).map{lastError =>
            Logger.debug(s"Successfully inserted with LastError: $lastError")
            Created
          }
        )

        val currencyRMB =  Map("account"-> account.email, "accountType"-> "RMB","amount"-> "0","frozenAmount" -> "0")
        AccountCurrency.form.bind(currencyRMB).fold(
          errors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s" Creating RMB currency account error")))),

          accountCurrency => AccountCurrency.collection.insert(accountCurrency.copy(
            id = accountCurrency.id.orElse(Some(UUID.randomUUID().toString)),
            createDate = Some(new DateTime()),
            updateDate = Some(new DateTime()))
          ).map{lastError =>
            Logger.debug(s"Successfully inserted with LastError: $lastError")
            Created
          }
        )
        val currencyUSD = Map("account"-> account.email, "accountType"-> "USD","amount"-> "0","frozenAmount" -> "0")
        AccountCurrency.form.bind(currencyUSD).fold(
          errors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s" Creating RMB currency account error")))),

          accountCurrency => AccountCurrency.collection.insert(accountCurrency.copy(
            id = accountCurrency.id.orElse(Some(UUID.randomUUID().toString)),
            createDate = Some(new DateTime()),
            updateDate = Some(new DateTime()))
          ).map{lastError =>
            Logger.debug(s"Successfully inserted with LastError: $lastError")
            Created
          }
        )
        val currencyGBP = Map("account"-> account.email, "accountType"-> "GBP","amount"-> "0","frozenAmount" -> "0")
        AccountCurrency.form.bind(currencyGBP).fold(
          errors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s" Creating RMB currency account error")))),

          accountCurrency => AccountCurrency.collection.insert(accountCurrency.copy(
            id = accountCurrency.id.orElse(Some(UUID.randomUUID().toString)),
            createDate = Some(new DateTime()),
            updateDate = Some(new DateTime()))
          ).map{lastError =>
            Logger.debug(s"Successfully inserted with LastError: $lastError")
            Created
          }
        )
      }
    )
//    val currencyBTC = Map("account" -> account.email, "accountType"->"BTC","amount"-> btc,"frozenAmount" -> btc)
//    AccountCurrency.form.bind(currencyBTC).fold(
//      formWithErrors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s"Account already exists for this user")))),
//      account => {
//        Account.collection.insert(account).map { lastError =>
//          Logger.debug(s"Successfully inserted with LastError: $lastError")
//          Created
//        }
//      }
//    )

  }


  // Handles the email-password sent as JSON:
 /*
  def authenticate = Action.async{ implicit

    request =>
      val account = request.body.asInstanceOf[AnyContentAsJson].json.as[Account]

    // let's do our query
    val cursor: Cursor[Account] = collection.
      // find all people with name `name`
      find(Json.obj("email" -> account.email,"password"-> account.password)).
      // sort them by creation date
      //      sort(Json.obj("created" -> -1)).
      // perform the query and get a cursor of JsObject
      cursor[Account]()
    // gather all the JsObjects in a list

    val futureUsersList: Future[List[Account]] = cursor.collect[List]()

    futureUsersList.map { list =>
      if(list.size < 1){
        Ok(Json.obj("success" -> false, "message" -> s"Bad Request: No user"))
      }else{
        Ok(Json.obj("success" -> true, "message" -> s"Login sucess"))
      }
    }
  }
*/

  /**
    * login authetication
    * @return
    */
  def authenticate = Action.async{ implicit request =>
   val account = request.body.asInstanceOf[AnyContentAsJson].json.as[Profile]
   val anyData = Map("email" -> account.email, "password" -> account.password)
    Account.loginForm.bind(anyData).fold(
      formWithErrors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s"Invalid email or password")))),
      account => {
        Future.successful(Ok(Json.obj("success" -> true,"message" -> account.get.email)))
      }
    )
  }

  /**
    * change password
    * @return
    */
  def change = Action.async{ implicit request =>
    val account = request.body.asInstanceOf[AnyContentAsJson].json.as[User]
    val email = account.email
    val anyData = Map("email" -> account.email, "password" -> account.oldPassword)
    val updateData = Map("email"-> account.email,"password"->account.newPassword)
    Account.loginForm.bind(anyData).fold(
      formWithErrors => Future.successful(Ok((Json.obj("success" -> false, "message" -> s"Old password is snot matched")))),
      account => {
        Account.passwordResetForm.bind(updateData).fold(
          formWithErrors =>Future.successful(Ok((Json.obj("success" -> false, "message" -> s"Update error happened")))),
          password => {
            Account.collection.update(Json.obj(
              "email" -> email
            ),Json.obj(
              "$set" -> Json.obj("password" -> password)
            ))
          }
        )
        Future.successful(Ok(Json.obj("success" -> true,"message" -> account.get.email)))
      }
    )
  }

  def getAccountCurrency(account: String) = Action.async { implicit request =>

    val query = Json.obj(
      "$orderby" -> Json.obj( "accountType" -> 1 ),
      "$query" -> Json.obj("account" -> account))

    val activeSort = request.queryString.get("sort").
      flatMap(_.headOption).getOrElse("none")

    // the cursor of documents
    val found = AccountCurrency.collection.find(query).cursor[AccountCurrency]
    // build (asynchronously) a list containing all the articles
    found.collect[List]().map { currency =>
      Ok(Json.toJson(currency))
    }.recover {
      case e =>
        e.printStackTrace()
        BadRequest(e.getMessage())
    }
  }

  def getSpecificCurrency(account:String,currencyType:String) = Action.async{
    implicit request =>
      val currency = request.queryString.get("CurrencyInfo").flatMap(_.headOption).getOrElse("")
      val query = Json.obj(
        "$query" -> Json.obj("account" -> account,"accountType" -> currencyType))

      val activeSort = request.queryString.get("sort").
        flatMap(_.headOption).getOrElse("none")

      // the cursor of documents
      val found = AccountCurrency.collection.find(query).one[AccountCurrency]
      // build (asynchronously) a list containing all the articles
      found.map { currency =>
        Ok(Json.toJson(currency))
      }.recover {
        case e =>
          e.printStackTrace()
          BadRequest(e.getMessage())
      }
  }

}

